/* ============================================
   JM SERVICES AFRICA — JAVASCRIPT
   ============================================ */

// --- Mobile Menu ---
function toggleMob() {
    document.getElementById('mob-menu').classList.toggle('open');
}

// --- Toast ---
function toast(msg, ok) {
    ok = ok !== undefined ? ok : true;
    var t = document.getElementById('toast');
    t.textContent = msg;
    t.className = 'toast ' + (ok ? 'toast-ok' : 'toast-err');
    setTimeout(function() { t.classList.add('show'); }, 10);
    setTimeout(function() { t.classList.remove('show'); }, 3500);
}

// --- Intersection Observer (animations au scroll) ---
function observeAll() {
    var obs = new IntersectionObserver(function(entries) {
        entries.forEach(function(entry) {
            if (entry.isIntersecting) {
                entry.target.classList.add('vis');
                obs.unobserve(entry.target);
            }
        });
    }, { threshold: 0.1 });

    var els = document.querySelectorAll('.obs:not(.vis)');
    for (var i = 0; i < els.length; i++) {
        obs.observe(els[i]);
    }
}

// --- Compteurs animés ---
function startCounters() {
    var counters = document.querySelectorAll('.counter');
    for (var i = 0; i < counters.length; i++) {
        (function(el) {
            var target = parseInt(el.getAttribute('data-t'));
            var current = 0;
            var step = Math.max(1, Math.ceil(target / 40));
            var interval = setInterval(function() {
                current += step;
                if (current >= target) {
                    current = target;
                    clearInterval(interval);
                }
                el.textContent = current + '+';
            }, 40);
        })(counters[i]);
    }
}

// --- Navbar scroll ---
window.addEventListener('scroll', function() {
    var nav = document.getElementById('navbar');
    if (window.scrollY > 50) {
        nav.style.background = 'rgba(5,5,5,0.85)';
        nav.style.backdropFilter = 'blur(16px)';
        nav.style.borderBottom = '1px solid rgba(255,255,255,0.05)';
    } else {
        nav.style.background = 'transparent';
        nav.style.backdropFilter = 'none';
        nav.style.borderBottom = 'none';
    }
});

// --- Hero Canvas (particules) ---
function initCanvas() {
    var canvas = document.getElementById('hero-canvas');
    if (!canvas) return;
    var ctx = canvas.getContext('2d');
    var w, h, particles = [];

    function resize() {
        w = canvas.width = canvas.parentElement.offsetWidth;
        h = canvas.height = canvas.parentElement.offsetHeight;
    }
    resize();
    window.addEventListener('resize', resize);

    for (var i = 0; i < 80; i++) {
        particles.push({
            x: Math.random() * w,
            y: Math.random() * h,
            r: Math.random() * 1.5 + 0.5,
            vx: (Math.random() - 0.5) * 0.3,
            vy: (Math.random() - 0.5) * 0.3,
            o: Math.random() * 0.4 + 0.1
        });
    }

    function draw() {
        ctx.clearRect(0, 0, w, h);
        for (var i = 0; i < particles.length; i++) {
            var p = particles[i];
            p.x += p.vx;
            p.y += p.vy;
            if (p.x < 0) p.x = w;
            if (p.x > w) p.x = 0;
            if (p.y < 0) p.y = h;
            if (p.y > h) p.y = 0;
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
            ctx.fillStyle = 'rgba(249,115,22,' + p.o + ')';
            ctx.fill();
        }
        for (var i = 0; i < particles.length; i++) {
            for (var j = i + 1; j < particles.length; j++) {
                var dx = particles[i].x - particles[j].x;
                var dy = particles[i].y - particles[j].y;
                var dist = Math.sqrt(dx * dx + dy * dy);
                if (dist < 120) {
                    ctx.beginPath();
                    ctx.moveTo(particles[i].x, particles[i].y);
                    ctx.lineTo(particles[j].x, particles[j].y);
                    ctx.strokeStyle = 'rgba(249,115,22,' + (0.06 * (1 - dist / 120)) + ')';
                    ctx.lineWidth = 0.5;
                    ctx.stroke();
                }
            }
        }
        requestAnimationFrame(draw);
    }
    draw();
}

// --- Initialisation ---
document.addEventListener('DOMContentLoaded', function() {
    lucide.createIcons();
    observeAll();
    startCounters();
    initCanvas();
});