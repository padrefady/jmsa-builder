<?php
 $page = 'portfolio';
 $items = json_decode(file_get_contents('data/portfolio.json'), true) ?: [];
include 'includes/header.php';
?>

<section class="pt-32 pb-24 px-6">
    <div class="max-w-7xl mx-auto">

        <div class="text-center mb-16 obs">
            <span class="text-xs font-semibold text-brand-500 uppercase tracking-widest">Portfolio</span>
            <h1 class="text-4xl md:text-5xl font-semibold tracking-tight mt-4 mb-6 tgradw">
                Nos réalisations
            </h1>
            <p class="text-neutral-400 font-light max-w-2xl mx-auto">
                Découvrez quelques-uns de nos projets récents.
            </p>
        </div>

        <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            <?php foreach ($items as $p): ?>
            <div class="gcard overflow-hidden obs">
                <div class="h-52 overflow-hidden">
                    <img src="https://picsum.photos/seed/<?= htmlspecialchars($p['img']) ?>/600/450.jpg"
                         alt="<?= htmlspecialchars($p['nom']) ?>"
                         class="w-full h-full object-cover opacity-70 hover:opacity-90 hover:scale-105 transition-all duration-500">
                </div>
                <div class="p-6">
                    <span class="cat-badge"><?= htmlspecialchars($p['cat']) ?></span>
                    <h3 class="text-lg font-semibold mt-3 mb-2"><?= htmlspecialchars($p['nom']) ?></h3>
                    <p class="text-sm text-neutral-400 leading-relaxed"><?= htmlspecialchars($p['desc']) ?></p>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

    </div>
</section>

<?php include 'includes/footer.php'; ?>