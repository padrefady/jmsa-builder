<?php
 $page = 'contact';

// Traitement du formulaire
 $message_envoye = false;
 $erreur = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Récupération et nettoyage des données
    $nom    = trim(htmlspecialchars($_POST['nom'] ?? ''));
    $email  = trim(htmlspecialchars($_POST['email'] ?? ''));
    $tel    = trim(htmlspecialchars($_POST['tel'] ?? ''));
    $sujet  = trim(htmlspecialchars($_POST['sujet'] ?? ''));
    $msg    = trim(htmlspecialchars($_POST['message'] ?? ''));

    // Validation
    if (empty($nom) || empty($email) || empty($sujet) || empty($msg)) {
        $erreur = 'Veuillez remplir tous les champs obligatoires (*).';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $erreur = 'Veuillez entrer une adresse email valide.';
    } else {

        // --- ENVOI PAR EMAIL (décommentez et configurez) ---
        /*
        $to = 'contact@jmservices.africa';
        $subject = 'Contact JMSA : ' . $sujet;
        $body = "Nom: $nom\nEmail: $email\nTél: $tel\nSujet: $sujet\n\nMessage:\n$msg";
        $headers = "From: $email\r\nReply-To: $email\r\n";
        mail($to, $subject, $body, $headers);
        */

        // --- SAUVEGARDE DANS UN FICHIER (alternative simple) ---
        $ligne = date('Y-m-d H:i:s') . " | $nom | $email | $tel | $sujet | $msg" . PHP_EOL;
        file_put_contents('data/messages.txt', $ligne, FILE_APPEND);

        $message_envoye = true;
    }
}

include 'includes/header.php';
?>

<section class="pt-32 pb-24 px-6">
    <div class="max-w-7xl mx-auto">

        <div class="text-center mb-16 obs">
            <span class="text-xs font-semibold text-brand-500 uppercase tracking-widest">Contact</span>
            <h1 class="text-4xl md:text-5xl font-semibold tracking-tight mt-4 mb-6 tgradw">
                Parlons de votre projet
            </h1>
            <p class="text-neutral-400 font-light max-w-2xl mx-auto">
                Décrivez-nous votre besoin et nous vous répondrons sous 24h.
            </p>
        </div>

        <div class="grid lg:grid-cols-5 gap-12">

            <!-- Formulaire -->
            <div class="lg:col-span-3 obs">
                <?php if ($message_envoye): ?>
                    <div class="glass rounded-2xl p-8 text-center">
                        <div class="w-16 h-16 rounded-full bg-green-500/10 flex items-center justify-center mx-auto mb-4">
                            <i data-lucide="check-circle" class="w-8 h-8 text-green-400"></i>
                        </div>
                        <h2 class="text-xl font-semibold mb-2">Message envoyé !</h2>
                        <p class="text-sm text-neutral-400 mb-6">Merci <?= htmlspecialchars($nom) ?>, nous vous répondrons sous 24h.</p>
                        <a href="contact.php" class="btn-p text-sm">Envoyer un autre message</a>
                    </div>
                <?php else: ?>

                    <?php if ($erreur): ?>
                        <div class="glass rounded-2xl p-4 mb-6 border-red-500/30" style="border-color: rgba(239,68,68,.3);">
                            <p class="text-sm text-red-400"><?= $erreur ?></p>
                        </div>
                    <?php endif; ?>

                    <form method="POST" action="contact.php" class="glass rounded-2xl p-8 space-y-5">
                        <div class="grid sm:grid-cols-2 gap-5">
                            <div>
                                <label class="text-xs text-neutral-400 mb-2 block">Nom complet *</label>
                                <input type="text" name="nom" class="finput" placeholder="Votre nom"
                                       value="<?= htmlspecialchars($_POST['nom'] ?? '') ?>" required>
                            </div>
                            <div>
                                <label class="text-xs text-neutral-400 mb-2 block">Email *</label>
                                <input type="email" name="email" class="finput" placeholder="email@exemple.com"
                                       value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>
                            </div>
                        </div>
                        <div>
                            <label class="text-xs text-neutral-400 mb-2 block">Téléphone / WhatsApp</label>
                            <input type="tel" name="tel" class="finput" placeholder="+243 000 000 000"
                                   value="<?= htmlspecialchars($_POST['tel'] ?? '') ?>">
                        </div>
                        <div>
                            <label class="text-xs text-neutral-400 mb-2 block">Sujet *</label>
                            <select name="sujet" class="finput" required>
                                <option value="">Choisir un sujet</option>
                                <option <?= (($_POST['sujet'] ?? '') === 'Création de site web') ? 'selected' : '' ?>>Création de site web</option>
                                <option <?= (($_POST['sujet'] ?? '') === 'Application mobile') ? 'selected' : '' ?>>Application mobile</option>
                                <option <?= (($_POST['sujet'] ?? '') === 'Accompagnement digital') ? 'selected' : '' ?>>Accompagnement digital</option>
                                <option <?= (($_POST['sujet'] ?? '') === 'Partenariat') ? 'selected' : '' ?>>Partenariat</option>
                                <option <?= (($_POST['sujet'] ?? '') === 'Autre') ? 'selected' : '' ?>>Autre</option>
                            </select>
                        </div>
                        <div>
                            <label class="text-xs text-neutral-400 mb-2 block">Message *</label>
                            <textarea name="message" class="finput" placeholder="Décrivez votre projet ou besoin..." required><?= htmlspecialchars($_POST['message'] ?? '') ?></textarea>
                        </div>
                        <button type="submit" class="btn-p w-full justify-center text-sm py-3.5">
                            Envoyer le message <i data-lucide="send" class="w-4 h-4"></i>
                        </button>
                    </form>
                <?php endif; ?>
            </div>

            <!-- Informations de contact -->
            <div class="lg:col-span-2 obs d2 space-y-6">
                <div class="glass rounded-2xl p-6">
                    <div class="flex items-center gap-4 mb-3">
                        <div class="w-10 h-10 rounded-lg bg-brand-500/10 flex items-center justify-center">
                            <i data-lucide="message-circle" class="w-5 h-5 text-brand-500"></i>
                        </div>
                        <h3 class="font-medium text-sm">WhatsApp</h3>
                    </div>
                    <p class="text-sm text-neutral-400">Réponse rapide, échange direct</p>
                    <a href="https://wa.me/243000000000" target="_blank" class="text-sm text-brand-500 font-medium mt-2 inline-block">+243 000 000 000</a>
                </div>
                <div class="glass rounded-2xl p-6">
                    <div class="flex items-center gap-4 mb-3">
                        <div class="w-10 h-10 rounded-lg bg-brand-500/10 flex items-center justify-center">
                            <i data-lucide="mail" class="w-5 h-5 text-brand-500"></i>
                        </div>
                        <h3 class="font-medium text-sm">Email</h3>
                    </div>
                    <p class="text-sm text-neutral-400">Pour les demandes détaillées</p>
                    <a href="mailto:contact@jmservices.africa" class="text-sm text-brand-500 font-medium mt-2 inline-block">contact@jmservices.africa</a>
                </div>
                <div class="glass rounded-2xl p-6">
                    <div class="flex items-center gap-4 mb-3">
                        <div class="w-10 h-10 rounded-lg bg-brand-500/10 flex items-center justify-center">
                            <i data-lucide="map-pin" class="w-5 h-5 text-brand-500"></i>
                        </div>
                        <h3 class="font-medium text-sm">Localisation</h3>
                    </div>
                    <p class="text-sm text-neutral-400">Basés en République Démocratique du Congo, actifs en Afrique centrale et de l'Ouest.</p>
                </div>
                <div class="glass rounded-2xl p-6">
                    <div class="flex items-center gap-4 mb-3">
                        <div class="w-10 h-10 rounded-lg bg-brand-500/10 flex items-center justify-center">
                            <i data-lucide="clock" class="w-5 h-5 text-brand-500"></i>
                        </div>
                        <h3 class="font-medium text-sm">Disponibilité</h3>
                    </div>
                    <p class="text-sm text-neutral-400">Lun – Ven : 8h – 18h (GMT+1)<br>Support WhatsApp : 7j/7</p>
                </div>
            </div>

        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>