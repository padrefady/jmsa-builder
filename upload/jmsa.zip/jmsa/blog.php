<?php
 $page = 'blog';
 $articles = json_decode(file_get_contents('data/blog.json'), true) ?: [];
include 'includes/header.php';
?>

<section class="pt-32 pb-24 px-6">
    <div class="max-w-7xl mx-auto">

        <div class="text-center mb-16 obs">
            <span class="text-xs font-semibold text-brand-500 uppercase tracking-widest">Blog & Actualités</span>
            <h1 class="text-4xl md:text-5xl font-semibold tracking-tight mt-4 mb-6 tgradw">
                Restez informé
            </h1>
            <p class="text-neutral-400 font-light max-w-2xl mx-auto">
                Évolutions, projets et conseils autour du digital en Afrique.
            </p>
        </div>

        <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            <?php foreach ($articles as $a): ?>
            <div class="gcard overflow-hidden obs">
                <div class="h-48 overflow-hidden">
                    <img src="https://picsum.photos/seed/<?= htmlspecialchars($a['img']) ?>/600/400.jpg"
                         alt="<?= htmlspecialchars($a['titre']) ?>"
                         class="w-full h-full object-cover opacity-70 hover:opacity-90 hover:scale-105 transition-all duration-500">
                </div>
                <div class="p-6">
                    <div class="flex items-center gap-3 mb-3">
                        <span class="cat-badge"><?= htmlspecialchars($a['cat']) ?></span>
                        <span class="text-[10px] text-neutral-600"><?= htmlspecialchars($a['date']) ?></span>
                    </div>
                    <h3 class="text-base font-semibold mb-2 leading-snug"><?= htmlspecialchars($a['titre']) ?></h3>
                    <p class="text-sm text-neutral-500 leading-relaxed"><?= htmlspecialchars($a['desc']) ?></p>
                    <button class="text-sm text-brand-500 font-medium flex items-center gap-1 mt-4 hover:gap-2 transition-all"
                            onclick="toast('Article complet bientôt disponible')">
                        Lire <i data-lucide="arrow-right" class="w-4 h-4"></i>
                    </button>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

    </div>
</section>

<?php include 'includes/footer.php'; ?>