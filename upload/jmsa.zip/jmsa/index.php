<?php
/**
 * JM Services Africa — Page d'accueil
 */
 $page = 'accueil';

// Charger les produits (3 premiers pour l'aperçu)
 $produits = json_decode(file_get_contents('data/produits.json'), true) ?: [];
 $produits_accueil = array_slice($produits, 0, 3);

include 'includes/header.php';
?>

<!-- ==================== HERO ==================== -->
<section class="relative min-h-screen flex items-center justify-center overflow-hidden">
    <canvas id="hero-canvas"></canvas>

    <div class="absolute inset-0 z-0">
        <img src="https://picsum.photos/seed/africa-skyline-2024/1920/1080.jpg" alt=""
             class="w-full h-full object-cover opacity-20"
             style="filter: grayscale(40%) brightness(.6);">
        <div class="absolute inset-0 bg-gradient-to-b from-[#050505] via-transparent to-[#050505]"></div>
        <div class="absolute inset-0 bg-gradient-to-r from-[#050505] via-transparent to-[#050505] opacity-60"></div>
    </div>

    <div class="relative z-10 max-w-5xl mx-auto px-6 text-center pt-20">
        <div class="anim-up inline-flex items-center gap-2 px-4 py-2 rounded-full glass mb-8">
            <span class="w-2 h-2 rounded-full bg-brand-500 animate-pulse"></span>
            <span class="text-xs font-medium text-brand-300 tracking-wider uppercase">Startup technologique africaine</span>
        </div>

        <h1 class="anim-up d2 text-4xl sm:text-5xl md:text-7xl font-semibold tracking-tight leading-[1.1] mb-6">
            Construisons ensemble<br>
            <span class="tgrad">l'Afrique digitale</span>
        </h1>

        <p class="anim-up d4 text-base sm:text-lg font-light text-neutral-400 max-w-2xl mx-auto mb-10 leading-relaxed">
            JM Services Africa développe des solutions digitales pour les entreprises et les communautés africaines
        </p>

        <div class="anim-up d6 flex flex-col sm:flex-row items-center justify-center gap-4">
            <a href="solutions.php" class="btn-p text-sm py-3.5 px-8">
                Découvrir nos solutions <i data-lucide="arrow-right" class="w-4 h-4"></i>
            </a>
            <a href="contact.php" class="btn-s text-sm py-3.5 px-8">
                Créer mon site gratuitement <i data-lucide="sparkles" class="w-4 h-4"></i>
            </a>
        </div>

        <div class="anim-up d8 mt-16 grid grid-cols-3 gap-8 max-w-lg mx-auto">
            <div>
                <div class="text-2xl sm:text-3xl font-semibold counter" data-t="15">0</div>
                <div class="text-xs text-neutral-500 mt-1">Projets livrés</div>
            </div>
            <div>
                <div class="text-2xl sm:text-3xl font-semibold counter" data-t="5">0</div>
                <div class="text-xs text-neutral-500 mt-1">Produits lancés</div>
            </div>
            <div>
                <div class="text-2xl sm:text-3xl font-semibold counter" data-t="3">0</div>
                <div class="text-xs text-neutral-500 mt-1">Pays couverts</div>
            </div>
        </div>
    </div>

    <div class="absolute bottom-8 left-1/2 -translate-x-1/2 anim-fade d8"
         style="animation: float 3s ease-in-out infinite;">
        <i data-lucide="chevron-down" class="w-5 h-5 text-neutral-600"></i>
    </div>
</section>

<!-- ==================== QUI SOMMES-NOUS ==================== -->
<section class="py-24 px-6">
    <div class="max-w-7xl mx-auto">
        <div class="grid lg:grid-cols-2 gap-16 items-center">

            <div class="obs">
                <span class="text-xs font-semibold text-brand-500 uppercase tracking-widest">Qui nous sommes</span>
                <h2 class="text-3xl md:text-4xl font-semibold tracking-tight mt-4 mb-6 tgradw">
                    Une vision africaine,<br>une exécution mondiale
                </h2>
                <p class="text-neutral-400 font-light leading-relaxed mb-6">
                    JM Services Africa est une entreprise technologique qui conçoit et développe
                    des solutions digitales pensées pour les réalités africaines. Nous croyons que
                    la technologie doit être accessible, simple et efficace.
                </p>
                <p class="text-neutral-400 font-light leading-relaxed">
                    Fondée avec la conviction que l'Afrique mérite des outils numériques de qualité,
                    notre équipe combine expertise technique et connaissance du terrain.
                </p>
            </div>

            <div class="obs grid grid-cols-2 gap-4">
                <div class="gcard p-6">
                    <div class="w-10 h-10 rounded-lg bg-brand-500/10 flex items-center justify-center mb-4">
                        <i data-lucide="target" class="w-5 h-5 text-brand-500"></i>
                    </div>
                    <h3 class="font-medium text-sm mb-2">Mission</h3>
                    <p class="text-xs text-neutral-500 leading-relaxed">Démocratiser l'accès au digital pour les entreprises et communautés africaines</p>
                </div>
                <div class="gcard p-6 mt-8">
                    <div class="w-10 h-10 rounded-lg bg-brand-500/10 flex items-center justify-center mb-4">
                        <i data-lucide="eye" class="w-5 h-5 text-brand-500"></i>
                    </div>
                    <h3 class="font-medium text-sm mb-2">Vision</h3>
                    <p class="text-xs text-neutral-500 leading-relaxed">Devenir le leader des solutions digitales adaptées à l'Afrique d'ici 2030</p>
                </div>
                <div class="gcard p-6">
                    <div class="w-10 h-10 rounded-lg bg-brand-500/10 flex items-center justify-center mb-4">
                        <i data-lucide="heart" class="w-5 h-5 text-brand-500"></i>
                    </div>
                    <h3 class="font-medium text-sm mb-2">Valeurs</h3>
                    <p class="text-xs text-neutral-500 leading-relaxed">Simplicité, impact, innovation et proximité avec nos utilisateurs</p>
                </div>
                <div class="gcard p-6 mt-8">
                    <div class="w-10 h-10 rounded-lg bg-brand-500/10 flex items-center justify-center mb-4">
                        <i data-lucide="users" class="w-5 h-5 text-brand-500"></i>
                    </div>
                    <h3 class="font-medium text-sm mb-2">Équipe</h3>
                    <p class="text-xs text-neutral-500 leading-relaxed">Des passionnés du digital engagés pour le développement de l'Afrique</p>
                </div>
            </div>

        </div>
    </div>
</section>

<div class="divider max-w-7xl mx-auto"></div>

<!-- ==================== SOLUTIONS APERÇU ==================== -->
<section class="py-24 px-6">
    <div class="max-w-7xl mx-auto">

        <div class="text-center mb-16 obs">
            <span class="text-xs font-semibold text-brand-500 uppercase tracking-widest">Nos solutions</span>
            <h2 class="text-3xl md:text-4xl font-semibold tracking-tight mt-4 tgradw">
                Des outils pensés pour l'Afrique
            </h2>
            <p class="text-neutral-400 font-light mt-4 max-w-xl mx-auto">
                Chaque solution est conçue pour répondre à un besoin réel
            </p>
        </div>

        <div class="grid md:grid-cols-3 gap-6">

            <!-- JMSA Builder -->
            <div class="gcard p-8 obs">
                <div class="w-12 h-12 rounded-xl bg-brand-500/10 flex items-center justify-center mb-6">
                    <i data-lucide="globe" class="w-6 h-6 text-brand-500"></i>
                </div>
                <h3 class="text-lg font-semibold mb-3">JMSA Builder</h3>
                <p class="text-sm text-neutral-400 leading-relaxed mb-6">
                    Création de sites web professionnels adaptés aux entreprises africaines.
                </p>
                <ul class="space-y-2 mb-6">
                    <li class="flex items-center gap-2 text-xs text-neutral-500">
                        <i data-lucide="check" class="w-3.5 h-3.5 text-brand-500"></i>
                        Sites vitrines & e-commerce
                    </li>
                    <li class="flex items-center gap-2 text-xs text-neutral-500">
                        <i data-lucide="check" class="w-3.5 h-3.5 text-brand-500"></i>
                        Responsive mobile-first
                    </li>
                    <li class="flex items-center gap-2 text-xs text-neutral-500">
                        <i data-lucide="check" class="w-3.5 h-3.5 text-brand-500"></i>
                        Optimisé SEO local
                    </li>
                </ul>
                <a href="solutions.php" class="text-sm text-brand-500 font-medium flex items-center gap-1 hover:gap-2 transition-all">
                    En savoir plus <i data-lucide="arrow-right" class="w-4 h-4"></i>
                </a>
            </div>

            <!-- Applications Mobiles -->
            <div class="gcard p-8 obs d2">
                <div class="w-12 h-12 rounded-xl bg-brand-500/10 flex items-center justify-center mb-6">
                    <i data-lucide="smartphone" class="w-6 h-6 text-brand-500"></i>
                </div>
                <h3 class="text-lg font-semibold mb-3">Applications mobiles</h3>
                <p class="text-sm text-neutral-400 leading-relaxed mb-6">
                    Des applications intuitives pour particuliers et entreprises.
                </p>
                <ul class="space-y-2 mb-6">
                    <li class="flex items-center gap-2 text-xs text-neutral-500">
                        <i data-lucide="check" class="w-3.5 h-3.5 text-brand-500"></i>
                        Android & iOS
                    </li>
                    <li class="flex items-center gap-2 text-xs text-neutral-500">
                        <i data-lucide="check" class="w-3.5 h-3.5 text-brand-500"></i>
                        Fonctionne hors-ligne
                    </li>
                    <li class="flex items-center gap-2 text-xs text-neutral-500">
                        <i data-lucide="check" class="w-3.5 h-3.5 text-brand-500"></i>
                        Interface simplifiée
                    </li>
                </ul>
                <a href="solutions.php" class="text-sm text-brand-500 font-medium flex items-center gap-1 hover:gap-2 transition-all">
                    En savoir plus <i data-lucide="arrow-right" class="w-4 h-4"></i>
                </a>
            </div>

            <!-- Solutions Communautaires -->
            <div class="gcard p-8 obs d4">
                <div class="w-12 h-12 rounded-xl bg-brand-500/10 flex items-center justify-center mb-6">
                    <i data-lucide="heart-handshake" class="w-6 h-6 text-brand-500"></i>
                </div>
                <h3 class="text-lg font-semibold mb-3">Solutions communautaires</h3>
                <p class="text-sm text-neutral-400 leading-relaxed mb-6">
                    Outils numériques pour l'agriculture, la santé et le social.
                </p>
                <ul class="space-y-2 mb-6">
                    <li class="flex items-center gap-2 text-xs text-neutral-500">
                        <i data-lucide="check" class="w-3.5 h-3.5 text-brand-500"></i>
                        Agriculture intelligente
                    </li>
                    <li class="flex items-center gap-2 text-xs text-neutral-500">
                        <i data-lucide="check" class="w-3.5 h-3.5 text-brand-500"></i>
                        Santé connectée
                    </li>
                    <li class="flex items-center gap-2 text-xs text-neutral-500">
                        <i data-lucide="check" class="w-3.5 h-3.5 text-brand-500"></i>
                        Inclusion sociale
                    </li>
                </ul>
                <a href="solutions.php" class="text-sm text-brand-500 font-medium flex items-center gap-1 hover:gap-2 transition-all">
                    En savoir plus <i data-lucide="arrow-right" class="w-4 h-4"></i>
                </a>
            </div>

        </div>
    </div>
</section>

<div class="divider max-w-7xl mx-auto"></div>

<!-- ==================== PRODUITS APERÇU ==================== -->
<section class="py-24 px-6">
    <div class="max-w-7xl mx-auto">

        <div class="text-center mb-16 obs">
            <span class="text-xs font-semibold text-brand-500 uppercase tracking-widest">Nos produits</span>
            <h2 class="text-3xl md:text-4xl font-semibold tracking-tight mt-4 tgradw">
                Des solutions qui changent le quotidien
            </h2>
        </div>

        <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            <?php foreach ($produits_accueil as $p):
                $stClass = $p['status'] === 'active' ? 'st-active' : ($p['status'] === 'dev' ? 'st-dev' : 'st-soon');
                $stText  = $p['status'] === 'active' ? 'Actif' : ($p['status'] === 'dev' ? 'En développement' : 'Bientôt');
            ?>
            <div class="gcard overflow-hidden obs">
                <div class="h-48 overflow-hidden">
                    <img src="https://picsum.photos/seed/<?= htmlspecialchars($p['img']) ?>/600/400.jpg"
                         alt="<?= htmlspecialchars($p['nom']) ?>"
                         class="w-full h-full object-cover opacity-70 hover:opacity-90 hover:scale-105 transition-all duration-500">
                </div>
                <div class="p-6">
                    <div class="flex items-center justify-between mb-3">
                        <span class="text-xs text-neutral-500"><?= htmlspecialchars($p['cat']) ?></span>
                        <span class="text-[10px] font-medium px-2.5 py-1 rounded-full <?= $stClass ?>"><?= $stText ?></span>
                    </div>
                    <h3 class="text-lg font-semibold mb-2"><?= htmlspecialchars($p['nom']) ?></h3>
                    <p class="text-sm text-neutral-400 leading-relaxed mb-4"><?= htmlspecialchars($p['desc']) ?></p>
                    <?php if ($p['status'] === 'active'): ?>
                        <a href="<?= htmlspecialchars($p['lien']) ?>" class="btn-p text-xs py-2 px-4">
                            Accéder <i data-lucide="external-link" class="w-3 h-3"></i>
                        </a>
                    <?php else: ?>
                        <span class="text-xs text-neutral-600">Prochainement disponible</span>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

        <div class="text-center mt-10 obs">
            <a href="produits.php" class="btn-s">
                Voir tous les produits <i data-lucide="arrow-right" class="w-4 h-4"></i>
            </a>
        </div>
    </div>
</section>

<div class="divider max-w-7xl mx-auto"></div>

<!-- ==================== POURQUOI NOUS ==================== -->
<section class="py-24 px-6 relative overflow-hidden">
    <div class="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] rounded-full bg-brand-500/5 blur-[100px]"></div>

    <div class="max-w-7xl mx-auto relative">
        <div class="text-center mb-16 obs">
            <span class="text-xs font-semibold text-brand-500 uppercase tracking-widest">Pourquoi nous</span>
            <h2 class="text-3xl md:text-4xl font-semibold tracking-tight mt-4 tgradw">
                Ce qui nous différencie
            </h2>
        </div>

        <div class="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <div class="gcard p-6 text-center obs">
                <div class="w-14 h-14 rounded-full bg-brand-500/10 flex items-center justify-center mx-auto mb-4">
                    <i data-lucide="map-pin" class="w-6 h-6 text-brand-500"></i>
                </div>
                <h3 class="font-medium text-sm mb-2">Adapté à l'Afrique</h3>
                <p class="text-xs text-neutral-500 leading-relaxed">Solutions conçues pour les réalités locales</p>
            </div>
            <div class="gcard p-6 text-center obs d2">
                <div class="w-14 h-14 rounded-full bg-brand-500/10 flex items-center justify-center mx-auto mb-4">
                    <i data-lucide="zap" class="w-6 h-6 text-brand-500"></i>
                </div>
                <h3 class="font-medium text-sm mb-2">Simple</h3>
                <p class="text-xs text-neutral-500 leading-relaxed">Des interfaces accessibles à tous</p>
            </div>
            <div class="gcard p-6 text-center obs d4">
                <div class="w-14 h-14 rounded-full bg-brand-500/10 flex items-center justify-center mx-auto mb-4">
                    <i data-lucide="trending-up" class="w-6 h-6 text-brand-500"></i>
                </div>
                <h3 class="font-medium text-sm mb-2">Efficace</h3>
                <p class="text-xs text-neutral-500 leading-relaxed">Des résultats mesurables</p>
            </div>
            <div class="gcard p-6 text-center obs d6">
                <div class="w-14 h-14 rounded-full bg-brand-500/10 flex items-center justify-center mx-auto mb-4">
                    <i data-lucide="award" class="w-6 h-6 text-brand-500"></i>
                </div>
                <h3 class="font-medium text-sm mb-2">Orienté résultats</h3>
                <p class="text-xs text-neutral-500 leading-relaxed">Impact concret et durable</p>
            </div>
        </div>
    </div>
</section>

<div class="divider max-w-7xl mx-auto"></div>

<!-- ==================== CTA FINAL ==================== -->
<section class="py-24 px-6">
    <div class="max-w-4xl mx-auto obs">
        <div class="glass rounded-2xl p-12 md:p-16 relative overflow-hidden">
            <div class="absolute top-0 right-0 w-64 h-64 bg-brand-500/10 rounded-full blur-[80px]"></div>
            <div class="absolute bottom-0 left-0 w-48 h-48 bg-brand-500/5 rounded-full blur-[60px]"></div>
            <div class="relative text-center">
                <h2 class="text-3xl md:text-4xl font-semibold tracking-tight mb-4">
                    Lancez votre transformation<br><span class="tgrad">dès aujourd'hui</span>
                </h2>
                <p class="text-neutral-400 font-light mb-8 max-w-lg mx-auto">
                    Rejoignez les entreprises africaines qui font le choix du digital avec un partenaire de confiance.
                </p>
                <div class="flex flex-col sm:flex-row items-center justify-center gap-4">
                    <a href="contact.php" class="btn-p text-sm py-3.5 px-8">
                        Démarrer un projet <i data-lucide="arrow-right" class="w-4 h-4"></i>
                    </a>
                    <a href="https://wa.me/243000000000" target="_blank" class="btn-s text-sm py-3.5 px-8">
                        <i data-lucide="message-circle" class="w-4 h-4"></i> WhatsApp
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>