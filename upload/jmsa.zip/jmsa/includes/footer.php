<?php
/**
 * JM Services Africa — Footer
 * Utilisation : include 'includes/footer.php';
 */
?>

</main>

<!-- ==================== FOOTER ==================== -->
<footer class="border-t border-white/5 py-16 px-6">
    <div class="max-w-7xl mx-auto">

        <div class="grid sm:grid-cols-2 lg:grid-cols-4 gap-10 mb-12">

            <!-- Colonne 1 : Logo & description -->
            <div>
                <div class="flex items-center gap-3 mb-4">
                    <div class="w-9 h-9 rounded-lg bg-brand-500 flex items-center justify-center font-bold text-sm">JM</div>
                    <span class="text-white font-semibold text-sm">JM Services Africa</span>
                </div>
                <p class="text-xs text-neutral-500 leading-relaxed">
                    Construisons ensemble l'Afrique digitale. Solutions technologiques adaptées aux réalités africaines.
                </p>
            </div>

            <!-- Colonne 2 : Navigation -->
            <div>
                <h4 class="text-sm font-medium mb-4">Navigation</h4>
                <ul class="space-y-2">
                    <li><a href="index.php" class="text-xs text-neutral-500 hover:text-brand-500 transition-colors">Accueil</a></li>
                    <li><a href="solutions.php" class="text-xs text-neutral-500 hover:text-brand-500 transition-colors">Solutions</a></li>
                    <li><a href="produits.php" class="text-xs text-neutral-500 hover:text-brand-500 transition-colors">Produits</a></li>
                    <li><a href="services.php" class="text-xs text-neutral-500 hover:text-brand-500 transition-colors">Services</a></li>
                </ul>
            </div>

            <!-- Colonne 3 : Entreprise -->
            <div>
                <h4 class="text-sm font-medium mb-4">Entreprise</h4>
                <ul class="space-y-2">
                    <li><a href="about.php" class="text-xs text-neutral-500 hover:text-brand-500 transition-colors">À propos</a></li>
                    <li><a href="portfolio.php" class="text-xs text-neutral-500 hover:text-brand-500 transition-colors">Portfolio</a></li>
                    <li><a href="blog.php" class="text-xs text-neutral-500 hover:text-brand-500 transition-colors">Blog</a></li>
                    <li><a href="contact.php" class="text-xs text-neutral-500 hover:text-brand-500 transition-colors">Contact</a></li>
                </ul>
            </div>

            <!-- Colonne 4 : Contact & réseaux -->
            <div>
                <h4 class="text-sm font-medium mb-4">Contact</h4>
                <ul class="space-y-2">
                    <li class="text-xs text-neutral-500">contact@jmservices.africa</li>
                    <li class="text-xs text-neutral-500">+243 000 000 000</li>
                    <li class="text-xs text-neutral-500">RDC — Afrique</li>
                </ul>
                <div class="flex gap-3 mt-4">
                    <a href="#" class="w-8 h-8 rounded-full bg-white/5 flex items-center justify-center hover:bg-brand-500/20 transition-colors">
                        <i data-lucide="twitter" class="w-3.5 h-3.5 text-neutral-500"></i>
                    </a>
                    <a href="#" class="w-8 h-8 rounded-full bg-white/5 flex items-center justify-center hover:bg-brand-500/20 transition-colors">
                        <i data-lucide="linkedin" class="w-3.5 h-3.5 text-neutral-500"></i>
                    </a>
                    <a href="#" class="w-8 h-8 rounded-full bg-white/5 flex items-center justify-center hover:bg-brand-500/20 transition-colors">
                        <i data-lucide="instagram" class="w-3.5 h-3.5 text-neutral-500"></i>
                    </a>
                    <a href="https://wa.me/243000000000" target="_blank" class="w-8 h-8 rounded-full bg-white/5 flex items-center justify-center hover:bg-brand-500/20 transition-colors">
                        <i data-lucide="message-circle" class="w-3.5 h-3.5 text-neutral-500"></i>
                    </a>
                </div>
            </div>
        </div>

        <div class="divider mb-8"></div>

        <div class="flex flex-col sm:flex-row items-center justify-between gap-4">
            <p class="text-xs text-neutral-600">&copy; <?= date('Y') ?> JM Services Africa. Tous droits réservés.</p>
            <p class="text-xs text-neutral-700">Conçu avec ❤️ en Afrique</p>
        </div>
    </div>
</footer>

<!-- JavaScript -->
<script src="assets/js/main.js"></script>

</body>
</html>