<?php $page = 'about'; include 'includes/header.php'; ?>

<section class="pt-32 pb-24 px-6">
    <div class="max-w-7xl mx-auto">

        <div class="text-center mb-20 obs">
            <span class="text-xs font-semibold text-brand-500 uppercase tracking-widest">À propos</span>
            <h1 class="text-4xl md:text-5xl font-semibold tracking-tight mt-4 mb-6 tgradw">Notre histoire</h1>
        </div>

        <!-- Histoire -->
        <div class="grid lg:grid-cols-2 gap-16 items-center mb-24 obs">
            <div class="relative">
                <div class="rounded-2xl overflow-hidden border border-white/10">
                    <img src="https://picsum.photos/seed/team-africa-tech/800/600.jpg" alt="Équipe" class="w-full h-auto opacity-80">
                </div>
                <div class="absolute -bottom-4 -right-4 w-40 h-40 bg-brand-500/10 rounded-full blur-[50px]"></div>
            </div>
            <div>
                <h2 class="text-2xl font-semibold tracking-tight mb-6">L'origine d'un rêve africain</h2>
                <p class="text-neutral-400 font-light leading-relaxed mb-4">
                    JM Services Africa est né d'un constat simple : l'Afrique regorge de talents et d'idées,
                    mais manque d'outils numériques adaptés à ses réalités. Chaque jour, des entrepreneurs,
                    des agriculteurs, des étudiants se heurtent à des solutions conçues ailleurs, pour d'autres contextes.
                </p>
                <p class="text-neutral-400 font-light leading-relaxed mb-4">
                    Nous avons décidé de changer cela. En créant JM Services Africa, nous nous sommes donné
                    pour mission de bâtir un écosystème digital qui parle africain, qui pense africain et qui
                    résout des problèmes africains.
                </p>
                <p class="text-neutral-400 font-light leading-relaxed">
                    Aujourd'hui, nous sommes fiers de compter plusieurs produits actifs, des clients satisfaits
                    et une communauté grandissante autour de notre vision.
                </p>
            </div>
        </div>

        <div class="divider mb-24"></div>

        <!-- Mission / Vision / Valeurs -->
        <div class="grid md:grid-cols-3 gap-8 obs">
            <div class="glass rounded-2xl p-8 text-center">
                <div class="w-16 h-16 rounded-full bg-brand-500/10 flex items-center justify-center mx-auto mb-6">
                    <i data-lucide="target" class="w-7 h-7 text-brand-500"></i>
                </div>
                <h3 class="text-lg font-semibold mb-3">Notre mission</h3>
                <p class="text-sm text-neutral-400 leading-relaxed">
                    Démocratiser l'accès au digital pour chaque entreprise et chaque communauté en Afrique,
                    en proposant des solutions abordables, simples et efficaces.
                </p>
            </div>
            <div class="glass rounded-2xl p-8 text-center">
                <div class="w-16 h-16 rounded-full bg-brand-500/10 flex items-center justify-center mx-auto mb-6">
                    <i data-lucide="eye" class="w-7 h-7 text-brand-500"></i>
                </div>
                <h3 class="text-lg font-semibold mb-3">Notre vision</h3>
                <p class="text-sm text-neutral-400 leading-relaxed">
                    Devenir d'ici 2030 la référence africaine en matière de solutions digitales,
                    en étant présent dans au moins 10 pays du continent.
                </p>
            </div>
            <div class="glass rounded-2xl p-8 text-center">
                <div class="w-16 h-16 rounded-full bg-brand-500/10 flex items-center justify-center mx-auto mb-6">
                    <i data-lucide="gem" class="w-7 h-7 text-brand-500"></i>
                </div>
                <h3 class="text-lg font-semibold mb-3">Nos valeurs</h3>
                <p class="text-sm text-neutral-400 leading-relaxed">
                    Simplicité — Nous rendons le complexe accessible.
                    Impact — Chaque ligne de code sert un but.
                    Proximité — Nous restons proches de nos utilisateurs.
                </p>
            </div>
        </div>

        <!-- Chiffres -->
        <div class="mt-24 obs">
            <h2 class="text-2xl font-semibold tracking-tight text-center mb-12">Quelques chiffres</h2>
            <div class="grid grid-cols-2 md:grid-cols-4 gap-6">
                <div class="glass rounded-2xl p-6 text-center">
                    <div class="text-3xl font-semibold tgrad">15+</div>
                    <div class="text-xs text-neutral-500 mt-2">Projets réalisés</div>
                </div>
                <div class="glass rounded-2xl p-6 text-center">
                    <div class="text-3xl font-semibold tgrad">5</div>
                    <div class="text-xs text-neutral-500 mt-2">Produits lancés</div>
                </div>
                <div class="glass rounded-2xl p-6 text-center">
                    <div class="text-3xl font-semibold tgrad">3</div>
                    <div class="text-xs text-neutral-500 mt-2">Pays couverts</div>
                </div>
                <div class="glass rounded-2xl p-6 text-center">
                    <div class="text-3xl font-semibold tgrad">100%</div>
                    <div class="text-xs text-neutral-500 mt-2">Passion & Engagement</div>
                </div>
            </div>
        </div>

    </div>
</section>

<?php include 'includes/footer.php'; ?>