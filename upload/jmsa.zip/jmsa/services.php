<?php $page = 'services'; include 'includes/header.php'; ?>

<section class="pt-32 pb-24 px-6">
    <div class="max-w-7xl mx-auto">

        <div class="text-center mb-20 obs">
            <span class="text-xs font-semibold text-brand-500 uppercase tracking-widest">Services</span>
            <h1 class="text-4xl md:text-5xl font-semibold tracking-tight mt-4 mb-6 tgradw">
                Ce que nous offrons
            </h1>
            <p class="text-neutral-400 font-light max-w-2xl mx-auto">
                Un accompagnement complet pour votre transformation digitale.
            </p>
        </div>

        <div class="space-y-8">

            <!-- Développement web -->
            <div class="gcard p-8 md:p-10 obs">
                <div class="grid lg:grid-cols-3 gap-8 items-center">
                    <div class="lg:col-span-2">
                        <div class="flex items-center gap-4 mb-4">
                            <div class="w-12 h-12 rounded-xl bg-brand-500/10 flex items-center justify-center">
                                <i data-lucide="code" class="w-6 h-6 text-brand-500"></i>
                            </div>
                            <div>
                                <h2 class="text-xl font-semibold">Développement web</h2>
                                <span class="text-xs text-neutral-500">Sites vitrines, e-commerce, plateformes</span>
                            </div>
                        </div>
                        <p class="text-sm text-neutral-400 leading-relaxed mb-4">
                            Sites web modernes, performants et optimisés pour convertir vos visiteurs en clients.
                        </p>
                        <div class="flex flex-wrap gap-2">
                            <span class="px-3 py-1 rounded-full text-xs bg-white/5 text-neutral-400">HTML/CSS/JS</span>
                            <span class="px-3 py-1 rounded-full text-xs bg-white/5 text-neutral-400">PHP</span>
                            <span class="px-3 py-1 rounded-full text-xs bg-white/5 text-neutral-400">WordPress</span>
                            <span class="px-3 py-1 rounded-full text-xs bg-white/5 text-neutral-400">SEO</span>
                        </div>
                    </div>
                    <div class="text-center lg:text-right">
                        <div class="text-3xl font-semibold tgrad mb-1">À partir de</div>
                        <div class="text-lg text-white">50$</div>
                        <a href="contact.php" class="btn-p mt-4 text-xs py-2 px-5 inline-flex">Demander un devis</a>
                    </div>
                </div>
            </div>

            <!-- Applications mobiles -->
            <div class="gcard p-8 md:p-10 obs">
                <div class="grid lg:grid-cols-3 gap-8 items-center">
                    <div class="lg:col-span-2">
                        <div class="flex items-center gap-4 mb-4">
                            <div class="w-12 h-12 rounded-xl bg-brand-500/10 flex items-center justify-center">
                                <i data-lucide="smartphone" class="w-6 h-6 text-brand-500"></i>
                            </div>
                            <div>
                                <h2 class="text-xl font-semibold">Applications mobiles</h2>
                                <span class="text-xs text-neutral-500">Android, iOS, hybrides</span>
                            </div>
                        </div>
                        <p class="text-sm text-neutral-400 leading-relaxed mb-4">
                            Du concept à la publication sur les stores, applications performantes avec UX soignée.
                        </p>
                        <div class="flex flex-wrap gap-2">
                            <span class="px-3 py-1 rounded-full text-xs bg-white/5 text-neutral-400">React Native</span>
                            <span class="px-3 py-1 rounded-full text-xs bg-white/5 text-neutral-400">Flutter</span>
                            <span class="px-3 py-1 rounded-full text-xs bg-white/5 text-neutral-400">Android</span>
                            <span class="px-3 py-1 rounded-full text-xs bg-white/5 text-neutral-400">iOS</span>
                        </div>
                    </div>
                    <div class="text-center lg:text-right">
                        <div class="text-3xl font-semibold tgrad mb-1">À partir de</div>
                        <div class="text-lg text-white">200$</div>
                        <a href="contact.php" class="btn-p mt-4 text-xs py-2 px-5 inline-flex">Demander un devis</a>
                    </div>
                </div>
            </div>

            <!-- Accompagnement digital -->
            <div class="gcard p-8 md:p-10 obs">
                <div class="grid lg:grid-cols-3 gap-8 items-center">
                    <div class="lg:col-span-2">
                        <div class="flex items-center gap-4 mb-4">
                            <div class="w-12 h-12 rounded-xl bg-brand-500/10 flex items-center justify-center">
                                <i data-lucide="compass" class="w-6 h-6 text-brand-500"></i>
                            </div>
                            <div>
                                <h2 class="text-xl font-semibold">Accompagnement digital</h2>
                                <span class="text-xs text-neutral-500">Conseil, stratégie, formation</span>
                            </div>
                        </div>
                        <p class="text-sm text-neutral-400 leading-relaxed mb-4">
                            Conseils stratégiques personnalisés, formations pratiques et suivi continu.
                        </p>
                        <div class="flex flex-wrap gap-2">
                            <span class="px-3 py-1 rounded-full text-xs bg-white/5 text-neutral-400">Stratégie</span>
                            <span class="px-3 py-1 rounded-full text-xs bg-white/5 text-neutral-400">Formation</span>
                            <span class="px-3 py-1 rounded-full text-xs bg-white/5 text-neutral-400">Audit</span>
                            <span class="px-3 py-1 rounded-full text-xs bg-white/5 text-neutral-400">Coaching</span>
                        </div>
                    </div>
                    <div class="text-center lg:text-right">
                        <div class="text-3xl font-semibold tgrad mb-1">Sur mesure</div>
                        <div class="text-lg text-white">Contactez-nous</div>
                        <a href="contact.php" class="btn-p mt-4 text-xs py-2 px-5 inline-flex">En discuter</a>
                    </div>
                </div>
            </div>

        </div>

        <!-- Processus -->
        <div class="mt-24 obs">
            <h2 class="text-2xl font-semibold tracking-tight text-center mb-12">Notre processus</h2>
            <div class="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
                <div class="text-center">
                    <div class="w-14 h-14 rounded-full border-2 border-brand-500/30 flex items-center justify-center mx-auto mb-4 text-brand-500 font-semibold">01</div>
                    <h3 class="font-medium text-sm mb-2">Écoute & Analyse</h3>
                    <p class="text-xs text-neutral-500">Comprendre vos besoins et analyser votre contexte</p>
                </div>
                <div class="text-center">
                    <div class="w-14 h-14 rounded-full border-2 border-brand-500/30 flex items-center justify-center mx-auto mb-4 text-brand-500 font-semibold">02</div>
                    <h3 class="font-medium text-sm mb-2">Conception</h3>
                    <p class="text-xs text-neutral-500">Design et architecture adaptés à votre projet</p>
                </div>
                <div class="text-center">
                    <div class="w-14 h-14 rounded-full border-2 border-brand-500/30 flex items-center justify-center mx-auto mb-4 text-brand-500 font-semibold">03</div>
                    <h3 class="font-medium text-sm mb-2">Développement</h3>
                    <p class="text-xs text-neutral-500">Codage propre, tests rigoureux, itérations rapides</p>
                </div>
                <div class="text-center">
                    <div class="w-14 h-14 rounded-full border-2 border-brand-500/30 flex items-center justify-center mx-auto mb-4 text-brand-500 font-semibold">04</div>
                    <h3 class="font-medium text-sm mb-2">Lancement & Suivi</h3>
                    <p class="text-xs text-neutral-500">Mise en ligne et accompagnement continu</p>
                </div>
            </div>
        </div>

    </div>
</section>

<?php include 'includes/footer.php'; ?>