<?php
 $page = 'produits';
 $produits = json_decode(file_get_contents('data/produits.json'), true) ?: [];
include 'includes/header.php';
?>

<section class="pt-32 pb-24 px-6">
    <div class="max-w-7xl mx-auto">

        <div class="text-center mb-16 obs">
            <span class="text-xs font-semibold text-brand-500 uppercase tracking-widest">Nos produits</span>
            <h1 class="text-4xl md:text-5xl font-semibold tracking-tight mt-4 mb-6 tgradw">
                Produits & Projets
            </h1>
            <p class="text-neutral-400 font-light max-w-2xl mx-auto">
                Découvrez nos produits conçus pour résoudre des problèmes concrets en Afrique.
            </p>
        </div>

        <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            <?php foreach ($produits as $p):
                $stClass = $p['status'] === 'active' ? 'st-active' : ($p['status'] === 'dev' ? 'st-dev' : 'st-soon');
                $stText  = $p['status'] === 'active' ? 'Actif' : ($p['status'] === 'dev' ? 'En développement' : 'Bientôt');
            ?>
            <div class="gcard overflow-hidden obs">
                <div class="h-48 overflow-hidden">
                    <img src="https://picsum.photos/seed/<?= htmlspecialchars($p['img']) ?>/600/400.jpg"
                         alt="<?= htmlspecialchars($p['nom']) ?>"
                         class="w-full h-full object-cover opacity-70 hover:opacity-90 hover:scale-105 transition-all duration-500">
                </div>
                <div class="p-6">
                    <div class="flex items-center justify-between mb-3">
                        <span class="text-xs text-neutral-500"><?= htmlspecialchars($p['cat']) ?></span>
                        <span class="text-[10px] font-medium px-2.5 py-1 rounded-full <?= $stClass ?>">
                            <?= $stText ?>
                        </span>
                    </div>
                    <h3 class="text-lg font-semibold mb-2"><?= htmlspecialchars($p['nom']) ?></h3>
                    <p class="text-sm text-neutral-400 leading-relaxed mb-4"><?= htmlspecialchars($p['desc']) ?></p>
                    <?php if ($p['status'] === 'active'): ?>
                        <a href="<?= htmlspecialchars($p['lien']) ?>" class="btn-p text-xs py-2 px-4">
                            Accéder <i data-lucide="external-link" class="w-3 h-3"></i>
                        </a>
                    <?php else: ?>
                        <span class="text-xs text-neutral-600">Prochainement disponible</span>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

    </div>
</section>

<?php include 'includes/footer.php'; ?>