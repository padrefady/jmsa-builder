<?php $page = 'solutions'; include 'includes/header.php'; ?>

<section class="pt-32 pb-24 px-6">
    <div class="max-w-7xl mx-auto">

        <div class="text-center mb-20 obs">
            <span class="text-xs font-semibold text-brand-500 uppercase tracking-widest">Nos solutions</span>
            <h1 class="text-4xl md:text-5xl font-semibold tracking-tight mt-4 mb-6 tgradw">
                Solutions digitales sur mesure
            </h1>
            <p class="text-neutral-400 font-light max-w-2xl mx-auto">
                Nous développons des solutions adaptées aux besoins spécifiques des entreprises et communautés africaines.
            </p>
        </div>

        <!-- JMSA Builder -->
        <div class="grid lg:grid-cols-2 gap-12 items-center mb-24 obs">
            <div>
                <div class="inline-flex items-center gap-2 px-3 py-1.5 rounded-full glass mb-6">
                    <i data-lucide="globe" class="w-4 h-4 text-brand-500"></i>
                    <span class="text-xs font-medium text-brand-300">Création de sites web</span>
                </div>
                <h2 class="text-2xl md:text-3xl font-semibold tracking-tight mb-4">JMSA Builder</h2>
                <p class="text-neutral-400 font-light leading-relaxed mb-6">
                    Notre outil de création de sites permet à toute entreprise africaine d'avoir une
                    présence en ligne professionnelle. Que vous soyez un restaurant à Kinshasa, un artisan
                    à Abidjan ou une startup à Lagos.
                </p>
                <ul class="space-y-3 mb-8">
                    <li class="flex items-start gap-3 text-sm text-neutral-400">
                        <i data-lucide="check-circle" class="w-5 h-5 text-brand-500 mt-0.5 flex-shrink-0"></i>
                        Templates professionnels optimisés
                    </li>
                    <li class="flex items-start gap-3 text-sm text-neutral-400">
                        <i data-lucide="check-circle" class="w-5 h-5 text-brand-500 mt-0.5 flex-shrink-0"></i>
                        Hébergement performant
                    </li>
                    <li class="flex items-start gap-3 text-sm text-neutral-400">
                        <i data-lucide="check-circle" class="w-5 h-5 text-brand-500 mt-0.5 flex-shrink-0"></i>
                        Intégration Mobile Money
                    </li>
                    <li class="flex items-start gap-3 text-sm text-neutral-400">
                        <i data-lucide="check-circle" class="w-5 h-5 text-brand-500 mt-0.5 flex-shrink-0"></i>
                        Support en français et langues locales
                    </li>
                </ul>
                <a href="contact.php" class="btn-p">Créer mon site <i data-lucide="arrow-right" class="w-4 h-4"></i></a>
            </div>
            <div class="relative">
                <div class="rounded-2xl overflow-hidden border border-white/10">
                    <img src="https://picsum.photos/seed/jmsa-builder-2024/800/500.jpg" alt="JMSA Builder" class="w-full h-auto opacity-80">
                </div>
                <div class="absolute -bottom-4 -right-4 w-32 h-32 bg-brand-500/10 rounded-full blur-[40px]"></div>
            </div>
        </div>

        <div class="divider mb-24"></div>

        <!-- Applications Mobiles -->
        <div class="grid lg:grid-cols-2 gap-12 items-center mb-24 obs">
            <div class="order-2 lg:order-1 relative">
                <div class="rounded-2xl overflow-hidden border border-white/10">
                    <img src="https://picsum.photos/seed/mobile-app-dev-af/800/500.jpg" alt="Apps mobiles" class="w-full h-auto opacity-80">
                </div>
                <div class="absolute -top-4 -left-4 w-32 h-32 bg-brand-500/10 rounded-full blur-[40px]"></div>
            </div>
            <div class="order-1 lg:order-2">
                <div class="inline-flex items-center gap-2 px-3 py-1.5 rounded-full glass mb-6">
                    <i data-lucide="smartphone" class="w-4 h-4 text-brand-500"></i>
                    <span class="text-xs font-medium text-brand-300">Applications mobiles</span>
                </div>
                <h2 class="text-2xl md:text-3xl font-semibold tracking-tight mb-4">Applications sur mesure</h2>
                <p class="text-neutral-400 font-light leading-relaxed mb-6">
                    Des applications performantes pensées pour les conditions réelles africaines :
                    faible connectivité, batteries limitées, diversité d'appareils.
                </p>
                <ul class="space-y-3 mb-8">
                    <li class="flex items-start gap-3 text-sm text-neutral-400">
                        <i data-lucide="check-circle" class="w-5 h-5 text-brand-500 mt-0.5 flex-shrink-0"></i>
                        Mode hors-ligne avancé
                    </li>
                    <li class="flex items-start gap-3 text-sm text-neutral-400">
                        <i data-lucide="check-circle" class="w-5 h-5 text-brand-500 mt-0.5 flex-shrink-0"></i>
                        Optimisation batterie et données
                    </li>
                    <li class="flex items-start gap-3 text-sm text-neutral-400">
                        <i data-lucide="check-circle" class="w-5 h-5 text-brand-500 mt-0.5 flex-shrink-0"></i>
                        Appareils entrée de gamme
                    </li>
                    <li class="flex items-start gap-3 text-sm text-neutral-400">
                        <i data-lucide="check-circle" class="w-5 h-5 text-brand-500 mt-0.5 flex-shrink-0"></i>
                        Notifications intelligentes
                    </li>
                </ul>
                <a href="contact.php" class="btn-p">Parler de mon projet <i data-lucide="arrow-right" class="w-4 h-4"></i></a>
            </div>
        </div>

        <div class="divider mb-24"></div>

        <!-- Solutions Communautaires -->
        <div class="obs">
            <div class="text-center mb-12">
                <div class="inline-flex items-center gap-2 px-3 py-1.5 rounded-full glass mb-6">
                    <i data-lucide="heart-handshake" class="w-4 h-4 text-brand-500"></i>
                    <span class="text-xs font-medium text-brand-300">Impact social</span>
                </div>
                <h2 class="text-2xl md:text-3xl font-semibold tracking-tight mb-4">Solutions communautaires</h2>
                <p class="text-neutral-400 font-light max-w-2xl mx-auto">
                    Des outils numériques au service du développement des communautés.
                </p>
            </div>
            <div class="grid md:grid-cols-3 gap-6">
                <div class="gcard p-8">
                    <div class="text-3xl mb-4">🌾</div>
                    <h3 class="font-semibold mb-3">Agriculture</h3>
                    <p class="text-sm text-neutral-400 leading-relaxed">Suivi des cultures, prévisions météo, accès aux marchés et conseils agricoles.</p>
                </div>
                <div class="gcard p-8">
                    <div class="text-3xl mb-4">🏥</div>
                    <h3 class="font-semibold mb-3">Santé</h3>
                    <p class="text-sm text-neutral-400 leading-relaxed">Télémédecine, suivi de patients, gestion de stocks médicaux.</p>
                </div>
                <div class="gcard p-8">
                    <div class="text-3xl mb-4">🤝</div>
                    <h3 class="font-semibold mb-3">Social</h3>
                    <p class="text-sm text-neutral-400 leading-relaxed">Plateformes d'inclusion, d'éducation et d'empowerment.</p>
                </div>
            </div>
        </div>

    </div>
</section>

<?php include 'includes/footer.php'; ?>