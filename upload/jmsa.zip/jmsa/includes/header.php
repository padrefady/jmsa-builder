<?php
/**
 * JM Services Africa — Header & Navigation
 * Utilisation : include 'includes/header.php';
 * 
 * @param string $page  Nom de la page active (accueil, solutions, etc.)
 */
 $page = isset($page) ? $page : 'accueil';

// Liens de navigation
 $nav = [
    ['id' => 'accueil',    'label' => 'Accueil'],
    ['id' => 'solutions',  'label' => 'Solutions'],
    ['id' => 'produits',   'label' => 'Produits'],
    ['id' => 'services',   'label' => 'Services'],
    ['id' => 'portfolio',  'label' => 'Portfolio'],
    ['id' => 'blog',       'label' => 'Blog'],
    ['id' => 'about',      'label' => 'À propos'],
    ['id' => 'contact',    'label' => 'Contact']
];
?>
<!DOCTYPE html>
<html lang="fr" class="scroll-smooth">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="JM Services Africa — Solutions digitales adaptées aux réalités africaines.">
    <title>JM Services Africa — L'Afrique Digitale<?php if ($page !== 'accueil') echo ' — ' . ucfirst($page); ?></title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <!-- Lucide Icons -->
    <script src="https://unpkg.com/lucide@latest"></script>

    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: { sans: ['Inter', 'sans-serif'] },
                    colors: {
                        brand: {
                            50:'#FFF7ED',100:'#FFEDD5',200:'#FED7AA',300:'#FDBA74',
                            400:'#FB923C',500:'#F97316',600:'#EA580C',700:'#C2410C',
                            800:'#9A3412',900:'#7C2D12'
                        }
                    }
                }
            }
        }
    </script>

    <!-- Styles personnalisés -->
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="grid-bg">

<!-- ==================== NAVIGATION ==================== -->
<nav id="navbar" class="fixed top-0 left-0 right-0 z-50 transition-all duration-300">
    <div class="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">

        <!-- Logo -->
        <a href="index.php" class="flex items-center gap-3 group">
            <div class="w-9 h-9 rounded-lg bg-brand-500 flex items-center justify-center font-bold text-sm text-white group-hover:shadow-lg group-hover:shadow-brand-500/30 transition-all">
                JM
            </div>
            <span class="text-white font-semibold text-sm tracking-tight hidden sm:block">JM Services Africa</span>
        </a>

        <!-- Navigation Desktop -->
        <div class="hidden lg:flex items-center gap-8">
            <?php foreach ($nav as $item): ?>
                <a href="<?= $item['id'] === 'accueil' ? 'index.php' : $item['id'] . '.php' ?>"
                   class="navl <?= $page === $item['id'] ? 'on' : '' ?>">
                    <?= htmlspecialchars($item['label']) ?>
                </a>
            <?php endforeach; ?>
        </div>

        <!-- CTA + Burger -->
        <div class="flex items-center gap-4">
            <a href="contact.php" class="btn-p hidden sm:inline-flex text-xs py-2.5 px-5">
                Démarrer un projet
            </a>
            <button class="lg:hidden text-white p-2" onclick="toggleMob()">
                <i data-lucide="menu" class="w-5 h-5"></i>
            </button>
        </div>
    </div>
</nav>

<!-- ==================== MENU MOBILE ==================== -->
<div id="mob-menu" class="mob-menu">
    <button class="absolute top-5 right-6 text-white" onclick="toggleMob()">
        <i data-lucide="x" class="w-6 h-6"></i>
    </button>
    <?php foreach ($nav as $item): ?>
        <a href="<?= $item['id'] === 'accueil' ? 'index.php' : $item['id'] . '.php' ?>"
           class="navl" onclick="toggleMob()">
            <?= htmlspecialchars($item['label']) ?>
        </a>
    <?php endforeach; ?>
</div>

<!-- Toast -->
<div id="toast" class="toast"></div>

<main>